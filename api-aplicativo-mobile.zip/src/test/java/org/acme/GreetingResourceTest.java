package org.acme;

import io.quarkus.test.junit.QuarkusTest;


@QuarkusTest
public class GreetingResourceTest {

    

}